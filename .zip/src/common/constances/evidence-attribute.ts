export const evidenceAttributes = ["Ảnh bìa", "Ảnh nội dung", "Bìa mặt sau"];
