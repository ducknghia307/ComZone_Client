const HotComicCard = () => {
  return <div>asasdasdasd</div>;
};

export default HotComicCard;
