import React from 'react';

const ManageDeliveries = () => {
    return (
        <div>
            ModDeliveries
        </div>
    );
};

export default ManageDeliveries;