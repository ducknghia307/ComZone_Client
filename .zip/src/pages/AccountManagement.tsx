import AccountUser from "../components/accountmanagement/AccountUser";

const AccountManagement = () => {
  return (
    <div className="w-full overflow-x-hidden">
      <AccountUser />
    </div>
  );
};

export default AccountManagement;
