import React from "react";

const AnnouncementUser = () => {
  return <div></div>;
};
//   <div className="status-auction-tabs">
//       <span
//         className={`status-auction-tab ${selectedAuctionStatus === "all" ? "active" : ""
//           }`}
//         onClick={() => setSelectedAuctionStatus("all")}
//       >
//         Tất cả
//       </span>
//       <span
//         className={`status-auction-tab ${selectedAuctionStatus === "ONGOING" ? "active" : ""
//           }`}
//         onClick={() => setSelectedAuctionStatus("ONGOING")}
//       >
//         Đang diễn ra
//       </span>
//       <span
//         className={`status-auction-tab ${selectedAuctionStatus === "SUCCESSFUL" ? "active" : ""
//           }`}
//         onClick={() => setSelectedAuctionStatus("SUCCESSFUL")}
//       >
//         Kết Thúc
//       </span>
//       <span
//         className={`status-auction-tab ${
//           selectedAuctionStatus === "COMPLETED" ? "active" : ""
//         }`}
//         onClick={() => setSelectedAuctionStatus("COMPLETED")}
//       >
//         Hoàn thành
//       </span>
//       <span
//         className={`status-auction-tab ${selectedAuctionStatus === "FAILED" ? "active" : ""
//           }`}
//         onClick={() => setSelectedAuctionStatus("FAILED")}
//       >
//         Bị Hủy
//       </span>

export default AnnouncementUser;
