import ComicsDetailTemp from "../components/comic/ComicsDetail.temp";

const ComicDetails = () => {
  return (
    <div className="w-full">
      <ComicsDetailTemp />
    </div>
  );
};

export default ComicDetails;
