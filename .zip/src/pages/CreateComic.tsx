
import SellerCreateComic from '../components/comic/SellerCreateComic';

const CreateComic = () => {
    return (
        <div className="w-full overflow-x-hidden"><SellerCreateComic /></div>

    );
};

export default CreateComic;