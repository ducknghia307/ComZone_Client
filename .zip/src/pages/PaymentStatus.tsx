import React from "react";

const PaymentStatus = () => {
  return <div>asdasd</div>;
};

export default PaymentStatus;
