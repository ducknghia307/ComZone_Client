import { createAction } from "@reduxjs/toolkit";

export const revertAll = createAction("REVERT_ALL");
